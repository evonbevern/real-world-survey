import axios from 'axios'

// const apiClient = axios.create({
//   baseURL: `http://localhost:3000`,
//   withCredentials: false,
//   headers: {
//     Accept: 'application/json',
//     'Content-Type': 'application/json'
//   },
//   timeout: 10000
// })

// export default {
//   getResponses() {
//     return apiClient.get('/responses/')
//   },
//   getResponse(id) {
//     return apiClient.get('/responses/' + id)
//   },
//   postResponse(response) {
//     return apiClient.post('/responses', response)
//   }
// }

export default {
  getResponses() {
    console.log('in getResponses()')
    axios
      .post('src/ajaxfile.php', { request: 1 })
      .then(function(response) {
        return response.data
      })
      .catch(function(error) {
        console.log(error)
      })
  },
  getResponse() {},
  postResponse(response) {
    return axios
      .post('src/ajaxfile.php', {
        request: 2,
        name: response.name,
        email: response.email,
        age: response.age,
        currentRole: response.currentRole,
        reccomend: response.reccomend,
        favoriteFeature: response.favoriteFeature,
        improvements: JSON.stringify(response.improvements),
        additional: response.additional
      })
      .then(function(response) {
        alert('Response recorded!', response)
      })
      .catch(function(error) {
        console.log(error)
      })
  }
}
