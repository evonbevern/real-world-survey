<?php
include "config.php";

$data = json_decode(file_get_contents("php://input"));

$request = $data->request;

if($request == 1) {
    $userData = mysqli_query($con, "SELECT * FROM `real-world-responses`");
    echo 'importing';
    $response = array();

    while($row = mysqli_fetch_assoc($userData)) {
        $response[] = $row;
    }
    echo json_encode($response);
    exit;
}

if($request == 2) {
    $id = $data->id;
    $name = $data->name;
    $email - $data->email;
    $age = $data->age;
    $currentRole = $data->currentRole;
    $reccomend = $data->reccomend;
    $favoriteFeature = $data->favoriteFeature;
    $improvements = $data->improvements;
    $additional = $data->additional;

    mysqli_query($con, "INSERT INTO `responses` (`id`, `name`, `email`, `age`, `currentRole`, `reccomend`, `favoriteFeature`, `improvements`, `additional`) 
    VALUES ('".$id."', '".$name."', '".$email."', '".$age."', '".$currentRole."', '".$reccomend."', '".$favoriteFeature."', '".$improvements."', '".$additional."')");
    echo "Insert Success!";
    exit;
}