<template>
  <div>
    <label v-if="label">{{ label }}</label>
    <div v-for="option in options" :key="option">
      <label :for="option">{{ option }}</label>
      <input
        name="improvements"
        type="checkbox"
        :id="option"
        @change="updateValue"
        :value="option"
        v-bind="$attrs"
      />
    </div>
  </div>
</template>

<script>
import { boxMixin } from '../mixins/boxMixin'
export default {
  mixins: [boxMixin],
  inheritAttrs: false,
  model: {
    prop: 'checked',
    event: 'change'
  },
  props: {
    label: {
      type: String,
      default: ''
    },
    value: Array,
    checked: Boolean
  },
  methods: {
    updateValue(event) {
      this.$emit('input', event.target.checked)
    }
  },
  value: Array
}
</script>

<style scoped></style>
