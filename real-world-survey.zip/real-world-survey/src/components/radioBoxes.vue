<template>
  <div>
    <label v-if="label">{{ label }}</label>
    <div v-for="option in options" :key="option.rating">
      <label :for="option.text">{{ option.text }}</label>
      <input
        type="radio"
        :id="option.text"
        :value="option.rating"
        @input="updateValue"
        v-bind="$attrs"
        :selected="option === value"
      />
    </div>
  </div>
</template>

<script>
import { formFieldMixin } from '../mixins/formFieldMixin'
import { boxMixin } from '../mixins/boxMixin'
export default {
  mixins: [formFieldMixin, boxMixin],
  value: [String, Number]
}
</script>

<style scoped></style>
