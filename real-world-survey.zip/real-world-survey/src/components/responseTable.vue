<template>
  <table>
    <tr>
      <th>id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Age</th>
      <th>Current Role</th>
      <th>Reccomend?</th>
      <th>Favorite Feature</th>
      <th>Improvements</th>
      <th>Additional Comments</th>
    </tr>
    <tr v-for="response in responses" :key="response.id">
      <td>{{ response.id }}</td>
      <td>{{ response.name }}</td>
      <td>{{ response.email }}</td>
      <td>{{ response.age ? response.age : '-' }}</td>
      <td>{{ response.role }}</td>
      <td>{{ response.reccomend }}</td>
      <td>{{ response.favorite }}</td>
      <td>
        {{ response.improvements.length ? response.improvements : 'None' }}
      </td>
      <td>{{ response.additional ? response.additional : '-' }}</td>
    </tr>
  </table>
</template>

<script>
export default {
  props: {
    responses: {
      type: Array,
      required: true
    }
  }
}
</script>

<style scoped></style>
