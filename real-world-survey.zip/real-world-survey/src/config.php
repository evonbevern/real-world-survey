<?php

$host = "localhost";
$user = "root";
$password = "...";
$dbname = "real-world-survey";

$con = mysqli_connect($host, $user, $password, $dbname);
if(!$con)
{
    die("Connection Failed: " .mysqli_connect_error());
}
else{console.log("Connected");}
