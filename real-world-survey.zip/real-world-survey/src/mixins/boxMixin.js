export const boxMixin = {
  props: {
    options: {
      type: Array,
      required: true
    }
  }
}
