import Vue from 'vue'
import VueRouter from 'vue-router'
import Survey from '../views/Survey.vue'
import responseCompleted from '../views/responseCompleted.vue'
import responses from '../views/responses.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'survey',
    component: Survey
  },
  {
    path: '/thank-you',
    name: 'response-completed',
    component: responseCompleted
  },
  {
    path: '/stats',
    name: 'response-data',
    component: responses
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
