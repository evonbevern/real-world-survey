import Vue from 'vue'
import Vuex from 'vuex'
import * as response from '@/store/modules/response.js'
import * as responseOptions from '@/store/modules/responseOptions.js'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {},
  mutations: {},
  actions: {},
  modules: {
    response,
    responseOptions
  }
})
