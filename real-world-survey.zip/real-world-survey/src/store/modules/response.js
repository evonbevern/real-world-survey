import EventService from '@/EventServices/EventService.js'

export const state = {
  totalResponses: 0,
  response: {},
  responses: []
}

export const mutations = {
  ADD_RESPONSE(state, response) {
    state.responses.push(response)
  },
  SET_RESPONSES(state, responses) {
    state.responses = responses
  },
  SET_RESPONSES_TOTAL(state, totalResponses) {
    state.totalResponses = totalResponses
  },
  SET_RESPONSE(state, response) {
    state.responses = response
  }
}

export const actions = {
  createResponse({ commit }, response) {
    return dispatch =>
      EventService.postResponse(response).then(() => {
        commit('ADD_RESPONSE', response)
      })
  },
  fetchResponses({ commit }) {
    return dispatch =>
      EventService.getResponses()
        .then(response => {
          commit('SET_RESPONSES', response.data)
        })
        .catch(error => {
          console.log(error)
        })
  }
}
