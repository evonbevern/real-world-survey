export const state = {
  roles: [
    'Student',
    'Full Time Job',
    'Full Time Learner',
    'Prefer Not to Say',
    'Other'
  ],
  feature: ['Challenges', 'Projects', 'Community', 'Open Source', 'Other'],
  reccomend: [
    { text: 'Extremeley Likely', rating: 5 },
    { text: 'Very Likely', rating: 4 },
    { text: 'Somewhat Likeley', rating: 3 },
    { text: 'Not Likeley', rating: 2 },
    { text: 'Very Unlikely', rating: 1 }
  ],
  improvements: [
    'Front-end Projects',
    'Back-end Projects',
    'Data Visualization',
    'Challenges',
    'Open Source Community',
    'Glitter Help Rooms',
    'Videos',
    'City Meetups',
    'Wiki',
    'Forum',
    'Additional Courses'
  ]
}
