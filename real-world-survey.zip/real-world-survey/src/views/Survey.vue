<template>
  <form>
    <form @submit.prevent="createResponse">
      <div class="row">
        <div class="column">
          <BaseInput
            label="Name *"
            type="text"
            v-model="response.name"
            placeholder="Enter your Name"
            :class="{ error: $v.response.name.$error }"
            @blur="$v.response.name.$touch"
          />
          <template v-if="$v.response.name.$error">
            <p v-if="!$v.response.name.required" class="errorMessage">
              Name is required
            </p>
          </template>

          <BaseInput
            label="Email *"
            type="email"
            v-model="response.email"
            placeholder="Enter your Email"
            :class="{ error: $v.response.email.$error }"
            @blur="$v.response.email.$touch"
          />
          <div v-if="$v.response.email.$error">
            <p class="errorMessage" v-if="!$v.response.email.email">
              Please enter a valid email address.
            </p>
            <p class="errorMessage" v-if="!$v.response.email.required">
              Email is required.
            </p>
          </div>

          <BaseInput
            label="Age (Optional)"
            type="number"
            v-model="response.age"
            placeholder="Age"
            min="10"
            max="100"
          />

          <BaseSelect
            label="Which option best describes your current role? *"
            :options="roles"
            v-model="response.role"
            :class="{ error: $v.response.favorite.$error }"
            @blur="$v.response.favorite.$touch"
          />
          <template v-if="$v.response.role.$error">
            <p v-if="!$v.response.role.required" class="errorMessage">
              Current role is required
            </p>
          </template>

          <radioBoxes
            :options="reccomend"
            name="reccomend"
            v-model="response.reccomend"
            label="How likely are you to reccomend freeCodeCamp to a friend? *"
            :class="{ error: $v.response.reccomend.$error }"
            @blur="$v.response.reccomend.$touch"
          />
          <template v-if="$v.response.reccomend.$error">
            <p v-if="!$v.response.reccomend.required" class="errorMessage">
              Reccomendation is required
            </p>
          </template>
        </div>
        <div class="column">
          <BaseSelect
            label="What is your favorite feature of freeCodeCamp? *"
            :options="features"
            v-model="response.favorite"
            :class="{ error: $v.response.favorite.$error }"
            @blur="$v.response.favorite.$touch"
          />
          <template v-if="$v.response.favorite.$error">
            <p v-if="!$v.response.favorite.required" class="errorMessage">
              Favorite Feature is required
            </p>
          </template>
          <!-- 
          <checkBoxes
            :options="improvements"
            name="improvements"
            v-model="response.improvements"
            label="What would you like to see improved? (Check all that apply)"
          />
           -->
          <div>
            <div v-for="improvement in improvements" :key="improvement">
              <label :for="improvement"
                >{{ improvement }}
                <input
                  name="improvements"
                  :id="improvement"
                  type="checkbox"
                  v-model="response.improvements"
                  :value="improvement"
              /></label>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom">
        <div id="additionalContainer" class="questionContainer">
          <p class="questionHeader" for="additional">
            Any comments or suggestions?
          </p>
          <br />
          <textarea
            id="additional"
            name="additional"
            v-model="response.additional"
            placeholder="Enter your comment here..."
          ></textarea>
        </div>

        <button id="submit" type="submit">SUBMIT</button>
        <p>* - Required Field</p>
      </div>
    </form>
  </form>
</template>

<script>
import radioBoxes from '@/components/radioBoxes.vue'

// import checkBoxes from '@/components/checkBoxes.vue'

import { required, email } from 'vuelidate/lib/validators'

export default {
  data() {
    return {
      improvements: this.$store.state.responseOptions.improvements,
      features: this.$store.state.responseOptions.feature,
      reccomend: this.$store.state.responseOptions.reccomend,
      roles: this.$store.state.responseOptions.roles,
      response: this.createFreshResponseObject()
    }
  },
  methods: {
    createResponse() {
      this.$v.$touch()
      if (!this.$v.$invalid) {
        this.$store
          .dispatch('createResponse', this.response)
          .then(() => {
            this.$router.push({
              name: 'response-completed'
            })
            this.event = this.createFreshEventObject()
          })
          .catch(() => {})
      }
    },
    createFreshResponseObject() {
      const id = Math.floor(Math.random() * 10000000)

      return {
        id: id,
        name: '',
        email: '',
        age: '',
        role: '',
        reccomend: '',
        favorite: '',
        improvements: [],
        additional: ''
      }
    }
  },
  validations: {
    response: {
      name: { required },
      email: { required, email },
      role: { required },
      reccomend: { required },
      favorite: { required }
    }
  },
  components: {
    radioBoxes
    //checkBoxes
  }
}
</script>

<style scoped></style>
