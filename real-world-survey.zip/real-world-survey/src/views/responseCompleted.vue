<template>
  <div>
    <h1>Thank you for submitting your feedback to freeCodeCamp!</h1>
    <br />
    <router-link to="/"><h2>Submit another response</h2></router-link>
    <router-link to="/stats"><h2>View Statistics</h2></router-link>
  </div>
</template>

<script>
export default {}
</script>

<style scoped></style>
