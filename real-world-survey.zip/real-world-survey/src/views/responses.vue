<template>
  <div>
    <responseTable :responses="response.responses" />
  </div>
</template>

<script>
import responseTable from '@/components/responseTable.vue'
import { mapState } from 'vuex'
import store from '@/store/index'

export default {
  components: {
    responseTable
  },
  mounted() {
    //console.log('fetchResponses next')
    store.dispatch('fetchResponses')
  },
  computed: {
    ...mapState(['response'])
  }
}
</script>

<style scoped></style>
